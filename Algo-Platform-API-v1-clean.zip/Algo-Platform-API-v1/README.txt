Algo platform API v1 (draft)

Algo-Platform-API.html   Open in a browser. The integration guide, the WebSocket protocol and every
                         app endpoint, with search. Needs internet access to load the viewer.
openapi-app.json         The same contract in OpenAPI 3.1, for Postman, Swagger or code generators.
